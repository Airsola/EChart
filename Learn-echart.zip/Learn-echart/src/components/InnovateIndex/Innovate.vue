<template>
    <div>

    </div>
</template>
<style scoped>
    body{
        background-color:#ff0000;
    }
</style>
<script>

</script>
