<template>
    <div>
      <ul>
        <p>
        <li><router-link to="/Recruit/RecruitIndustry">招聘指数-各行业-Top10-最近5个月</router-link></li>
        </p>
      </ul>

      <router-view></router-view>
    </div>
</template>
<style scoped>

</style>
<script>

</script>
