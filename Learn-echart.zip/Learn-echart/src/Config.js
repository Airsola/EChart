export default{
          BASE_URL : 'http://172.16.131.235:8080/spider-web/riviews/gardenindex'
  }


